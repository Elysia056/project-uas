# 🛒 E-Commerce UAS — Amazon Clone (Laravel + MySQL)

## Pembagian Tugas Tim

| Anggota | Models | Controllers | Views |
|---------|--------|-------------|-------|
| **E** | `Product`, `Category` | `ProductController`, `CategoryController` | products/*, categories/* |
| **R** | `Cart`, `Wishlist` | `CartController`, `WishlistController` | cart/*, wishlist/* |
| **C** | `Order`, `OrderItem` | `OrderController`, `OrderItemController` | orders/*, order_items/* |
| **S** | `Review`, `Address` | `AuthController`, `ReviewController` | auth/*, reviews/* |

---

## Setup di Localhost (Step by Step)

### 1. Install Dependencies
```bash
composer install
```

### 2. Copy & Edit .env
```bash
cp .env.example .env
php artisan key:generate
```
Edit `.env`:
```
DB_DATABASE=ecommerce_uas
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Buat Database di PHPMyAdmin
- Buka `localhost/phpmyadmin`
- Buat database baru: `ecommerce_uas`

### 4. Jalankan Migrations & Seeder
```bash
php artisan migrate
php artisan db:seed
```

### 5. Jalankan Server
```bash
php artisan serve
```
Buka `http://localhost:8000`

### 6. Login Default
- Email: `admin@example.com`
- Password: `password`

---

## Struktur Folder Penting
```
app/
  Models/           → Semua Model (E, R, C, S)
  Http/Controllers/ → Semua Controller (E, R, C, S)
database/
  migrations/       → Schema tabel
  seeders/          → Data awal
resources/
  views/            → Semua Blade template
routes/
  web.php           → Semua route
```
