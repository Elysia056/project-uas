<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $fillable = ['name', 'email', 'password', 'role'];

    protected $hidden = ['password'];

    // Relasi: User punya banyak Order
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    // Relasi: User punya banyak Cart
    public function carts()
    {
        return $this->hasMany(Cart::class);
    }

    // Relasi: User punya banyak Wishlist
    public function wishlists()
    {
        return $this->hasMany(Wishlist::class);
    }

    // Relasi: User punya banyak Review
    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    // Relasi: User punya banyak Address
    public function addresses()
    {
        return $this->hasMany(Address::class);
    }

    // Cek apakah user adalah admin
    public function isAdmin()
    {
        return $this->role === 'admin';
    }
}
