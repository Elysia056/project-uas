# PANDUAN SETUP LENGKAP — E-Commerce UAS (ShopKita)

## =============================================
## LANGKAH 1: INSTALL LARAVEL BARU
## =============================================

Buka terminal / command prompt, jalankan:

```bash
composer create-project laravel/laravel shopkita
cd shopkita
```

---

## =============================================
## LANGKAH 2: COPY SEMUA FILE DARI PROJECT INI
## =============================================

Salin file-file dari folder ZIP ini ke dalam project laravel kamu:

| File dari ZIP ini          | Copy ke dalam project laravel     |
|----------------------------|-----------------------------------|
| app/Models/*               | app/Models/                       |
| app/Http/Controllers/*     | app/Http/Controllers/             |
| database/migrations/*      | database/migrations/              |
| database/seeders/*         | database/seeders/                 |
| resources/views/**/*       | resources/views/                  |
| routes/web.php             | routes/web.php (REPLACE)          |

---

## =============================================
## LANGKAH 3: BUAT DATABASE DI PHPMYADMIN
## =============================================

1. Nyalakan XAMPP → klik START pada Apache dan MySQL
2. Buka browser → http://localhost/phpmyadmin
3. Klik tombol "New" di sidebar kiri
4. Isi nama database: **ecommerce_uas**
5. Klik tombol "Create"

---

## =============================================
## LANGKAH 4: SETUP FILE .env
## =============================================

Di dalam folder project laravel, edit file `.env`:

```
APP_NAME=ShopKita

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecommerce_uas
DB_USERNAME=root
DB_PASSWORD=
```

> Catatan: Jika XAMPP MySQL kamu pakai password, isi DB_PASSWORD.

---

## =============================================
## LANGKAH 5: JALANKAN MIGRASI + SEEDER
## =============================================

```bash
php artisan migrate
php artisan db:seed
```

Setelah berhasil, cek di PHPMyAdmin → database ecommerce_uas
akan punya tabel: users, categories, products, carts, wishlists,
orders, order_items, reviews, addresses

---

## =============================================
## LANGKAH 6: JALANKAN SERVER
## =============================================

```bash
php artisan serve
```

Buka browser → http://localhost:8000

---

## =============================================
## AKUN LOGIN DEFAULT (dari seeder)
## =============================================

| Role  | Email               | Password |
|-------|---------------------|----------|
| Admin | admin@example.com   | password |
| User  | budi@example.com    | password |
| User  | siti@example.com    | password |

---

## =============================================
## PEMBAGIAN TUGAS TIM
## =============================================

### 👤 ORANG E — Produk & Kategori
| Komponen    | File                                              |
|-------------|---------------------------------------------------|
| Model 1     | app/Models/Category.php                           |
| Model 2     | app/Models/Product.php                            |
| Controller 1| app/Http/Controllers/CategoryController.php       |
| Controller 2| app/Http/Controllers/ProductController.php        |
| View 1a     | resources/views/categories/index.blade.php        |
| View 1b     | resources/views/categories/show.blade.php         |
| View 1c     | resources/views/categories/create.blade.php       |
| View 1d     | resources/views/categories/edit.blade.php         |
| View 2a     | resources/views/products/index.blade.php          |
| View 2b     | resources/views/products/show.blade.php           |
| View 2c     | resources/views/products/create.blade.php         |
| View 2d     | resources/views/products/edit.blade.php           |

### 👤 ORANG R — Keranjang & Wishlist
| Komponen    | File                                              |
|-------------|---------------------------------------------------|
| Model 1     | app/Models/Cart.php                               |
| Model 2     | app/Models/Wishlist.php                           |
| Controller 1| app/Http/Controllers/CartController.php           |
| Controller 2| app/Http/Controllers/WishlistController.php       |
| View 1a     | resources/views/cart/index.blade.php              |
| View 1b     | resources/views/cart/show.blade.php               |
| View 2a     | resources/views/wishlist/index.blade.php          |
| View 2b     | resources/views/wishlist/show.blade.php           |

### 👤 ORANG C — Pesanan & Item Pesanan
| Komponen    | File                                              |
|-------------|---------------------------------------------------|
| Model 1     | app/Models/Order.php                              |
| Model 2     | app/Models/OrderItem.php                          |
| Controller 1| app/Http/Controllers/OrderController.php          |
| Controller 2| app/Http/Controllers/OrderItemController.php      |
| View 1a     | resources/views/orders/index.blade.php            |
| View 1b     | resources/views/orders/show.blade.php             |
| View 1c     | resources/views/orders/create.blade.php           |
| View 1d     | resources/views/orders/edit.blade.php             |
| View 2a     | resources/views/order_items/index.blade.php       |
| View 2b     | resources/views/order_items/show.blade.php        |

### 👤 ORANG S — Auth, Review & Alamat
| Komponen    | File                                              |
|-------------|---------------------------------------------------|
| Model 1     | app/Models/Review.php                             |
| Model 2     | app/Models/Address.php                            |
| Controller 1| app/Http/Controllers/AuthController.php           |
| Controller 2| app/Http/Controllers/ReviewController.php         |
| View 1a     | resources/views/auth/login.blade.php              |
| View 1b     | resources/views/auth/register.blade.php           |
| View 2a     | resources/views/reviews/index.blade.php           |
| View 2b     | resources/views/reviews/create.blade.php          |
| View 2c     | resources/views/reviews/show.blade.php            |

---

## =============================================
## FITUR-FITUR APLIKASI
## =============================================

1. **Register & Login** — User bisa daftar dan masuk
2. **Lihat Produk** — Halaman utama menampilkan semua produk
3. **Detail Produk** — Lihat info lengkap + review + rating rata-rata
4. **Kelola Kategori** — Admin bisa tambah/edit/hapus kategori
5. **Kelola Produk** — Admin bisa tambah/edit/hapus produk
6. **Keranjang Belanja** — Tambah, update qty, hapus item
7. **Wishlist** — Simpan produk favorit, pindahkan ke cart
8. **Checkout** — Isi alamat → buat pesanan dari isi cart
9. **Riwayat Pesanan** — Lihat semua pesanan + detail item
10. **Review Produk** — Tulis dan hapus review dengan rating 1-5
11. **CSRF Protection** — Semua form pakai @csrf (sesuai materi)
12. **Auth Middleware** — Halaman penting terlindungi login

---

## =============================================
## ALUR MVC (sesuai materi PDF)
## =============================================

```
Browser → routes/web.php → Controller → Model → Database
                                     ↓
                              View (Blade)
                                     ↓
                              Browser (HTML)
```

Contoh: User buka /products
1. routes/web.php → ProductController@index
2. ProductController@index → Product::with('category')->get()
3. Model Product query ke tabel products di MySQL
4. Data dikembalikan ke view products/index.blade.php
5. Blade render HTML → tampil di browser
